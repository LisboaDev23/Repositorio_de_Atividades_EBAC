package com.gbLisboa.vendaCarro.ClienteService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClienteServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
